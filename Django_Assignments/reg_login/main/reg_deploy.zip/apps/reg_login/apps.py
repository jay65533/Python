from django.apps import AppConfig


class RegLoginConfig(AppConfig):
    name = 'reg_login'
